import { useParams, useOutletContext } from 'react-router-dom';
import { FileText } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export function ProjectDocuments() {
  const { projectId } = useParams<{ projectId: string }>();
  const context = useOutletContext<{ project: any }>();

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Documenti</h2>
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p className="text-lg font-medium">Gestione Documenti</p>
          <p className="mt-2">Questa funzionalità sarà disponibile a breve.</p>
          <p className="mt-1 text-sm">Potrai caricare e gestire documenti di progetto.</p>
        </CardContent>
      </Card>
    </div>
  );
}

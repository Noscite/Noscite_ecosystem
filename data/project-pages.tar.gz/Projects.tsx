import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, FolderKanban, Pencil, Trash2, Calendar, Users, Clock, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { api } from '@/api/client';

const projectsApi = {
  list: (params?: Record<string, any>) => api.get('/projects', { params }),
  create: (data: any) => api.post('/projects', data),
  update: (id: string, data: any) => api.put(`/projects/${id}`, data),
  delete: (id: string) => api.delete(`/projects/${id}`),
};

interface Project {
  id?: string;
  code?: string;
  order_id?: string | null;
  name: string;
  description?: string;
  methodology?: string;
  status: string;
  planned_start_date?: string;
  planned_end_date?: string;
  actual_start_date?: string;
  actual_end_date?: string;
  budget?: number | string;
  actual_cost?: number;
  progress_percentage?: number;
  color?: string;
  notes?: string;
  // Stats from view
  total_tasks?: number;
  completed_tasks?: number;
  total_milestones?: number;
  completed_milestones?: number;
  company_name?: string;
  order_number?: string;
}

const emptyProject: Project = {
  name: '',
  description: '',
  methodology: 'waterfall',
  status: 'planning',
  planned_start_date: '',
  planned_end_date: '',
  budget: '',
  progress_percentage: 0,
  color: '#3B82F6',
  notes: '',
};

const statusOptions = [
  { value: 'planning', label: 'Pianificazione', color: 'bg-gray-100 text-gray-800' },
  { value: 'in_progress', label: 'In Corso', color: 'bg-blue-100 text-blue-800' },
  { value: 'on_hold', label: 'Sospeso', color: 'bg-orange-100 text-orange-800' },
  { value: 'completed', label: 'Completato', color: 'bg-green-100 text-green-800' },
  { value: 'cancelled', label: 'Annullato', color: 'bg-red-100 text-red-800' },
];

const methodologyOptions = [
  { value: 'waterfall', label: 'Waterfall' },
  { value: 'agile', label: 'Agile' },
  { value: 'hybrid', label: 'Hybrid' },
];

export function Projects() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formData, setFormData] = useState<Project>(emptyProject);
  const queryClient = useQueryClient();

  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects', search],
    queryFn: () => projectsApi.list({ search: search || undefined }),
  });

  const createMutation = useMutation({
    mutationFn: (data: Project) => projectsApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setIsDialogOpen(false);
      setFormData(emptyProject);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Project }) => projectsApi.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setIsDialogOpen(false);
      setEditingProject(null);
      setFormData(emptyProject);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => projectsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
  });

  const handleOpenCreate = () => {
    setEditingProject(null);
    setFormData(emptyProject);
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (project: Project, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingProject(project);
    setFormData({
      ...project,
      planned_start_date: project.planned_start_date ? project.planned_start_date.split('T')[0] : '',
      planned_end_date: project.planned_end_date ? project.planned_end_date.split('T')[0] : '',
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSend = {
      ...formData,
      budget: formData.budget ? parseFloat(String(formData.budget)) : null,
      planned_start_date: formData.planned_start_date || null,
      planned_end_date: formData.planned_end_date || null,
    };
    if (editingProject?.id) {
      updateMutation.mutate({ id: editingProject.id, data: dataToSend });
    } else {
      createMutation.mutate(dataToSend);
    }
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Sei sicuro di voler eliminare questo progetto?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleProjectClick = (projectId: string) => {
    navigate(`/projects/${projectId}`);
  };

  const formatPrice = (price: any) => {
    const num = parseFloat(price);
    return isNaN(num) ? '0.00' : num.toFixed(2);
  };

  const getStatusInfo = (status: string) => {
    return statusOptions.find(s => s.value === status) || statusOptions[0];
  };

  const formatDate = (date?: string) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('it-IT');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Progetti</h1>
        <Button onClick={handleOpenCreate}>
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Progetto
        </Button>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Cerca progetti..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardHeader>
      </Card>

      {isLoading ? (
        <div className="text-center py-8">Caricamento...</div>
      ) : projects?.data?.length === 0 ? (
        <div className="text-center py-8 text-gray-500">Nessun progetto trovato</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects?.data?.map((project: Project) => {
            const statusInfo = getStatusInfo(project.status);
            const taskProgress = project.total_tasks 
              ? Math.round((project.completed_tasks || 0) / project.total_tasks * 100) 
              : 0;
            
            return (
              <Card 
                key={project.id} 
                className="cursor-pointer hover:shadow-lg transition-shadow border-l-4"
                style={{ borderLeftColor: project.color || '#3B82F6' }}
                onClick={() => handleProjectClick(project.id!)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div 
                        className="flex h-12 w-12 items-center justify-center rounded-lg"
                        style={{ backgroundColor: `${project.color}20` }}
                      >
                        <FolderKanban className="h-6 w-6" style={{ color: project.color }} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{project.name}</h3>
                        <p className="text-sm text-gray-500">{project.code}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={(e) => handleOpenEdit(project, e)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={(e) => handleDelete(project.id!, e)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </div>

                  {project.company_name && (
                    <p className="text-sm text-gray-600 mb-3">{project.company_name}</p>
                  )}

                  <div className="flex items-center gap-2 mb-4">
                    <span className={`px-2 py-1 rounded-full text-xs ${statusInfo.color}`}>
                      {statusInfo.label}
                    </span>
                    <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-700">
                      {methodologyOptions.find(m => m.value === project.methodology)?.label || 'Waterfall'}
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Progresso</span>
                      <span className="font-medium">{project.progress_percentage || 0}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full transition-all" 
                        style={{ 
                          width: `${project.progress_percentage || 0}%`,
                          backgroundColor: project.color || '#3B82F6'
                        }}
                      />
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <FileText className="h-4 w-4" />
                      <span>{project.completed_tasks || 0}/{project.total_tasks || 0} Task</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span>{project.completed_milestones || 0}/{project.total_milestones || 0} Milestone</span>
                    </div>
                  </div>

                  {/* Dates */}
                  <div className="mt-4 pt-4 border-t flex justify-between text-sm text-gray-500">
                    <span>Inizio: {formatDate(project.planned_start_date)}</span>
                    <span>Fine: {formatDate(project.planned_end_date)}</span>
                  </div>

                  {/* Budget */}
                  {project.budget && (
                    <div className="mt-2 text-sm">
                      <span className="text-gray-600">Budget: </span>
                      <span className="font-medium">€{formatPrice(project.budget)}</span>
                      {project.actual_cost !== undefined && (
                        <span className="text-gray-500"> (Speso: €{formatPrice(project.actual_cost)})</span>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProject ? 'Modifica Progetto' : 'Nuovo Progetto'}</DialogTitle>
            <DialogDescription>
              {editingProject ? 'Modifica i dati del progetto' : 'Inserisci i dati del nuovo progetto'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="color">Colore</Label>
                  <div className="flex gap-2">
                    <Input
                      id="color"
                      type="color"
                      value={formData.color || '#3B82F6'}
                      onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                      className="w-16 h-9 p-1"
                    />
                    <Input
                      value={formData.color || '#3B82F6'}
                      onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                      className="flex-1"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrizione</Label>
                <Textarea
                  id="description"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Stato</Label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="flex h-9 w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {statusOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="methodology">Metodologia</Label>
                  <select
                    id="methodology"
                    value={formData.methodology || 'waterfall'}
                    onChange={(e) => setFormData({ ...formData, methodology: e.target.value })}
                    className="flex h-9 w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {methodologyOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="budget">Budget (€)</Label>
                  <Input
                    id="budget"
                    type="number"
                    step="0.01"
                    value={formData.budget || ''}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="planned_start_date">Data Inizio Prevista</Label>
                  <Input
                    id="planned_start_date"
                    type="date"
                    value={formData.planned_start_date || ''}
                    onChange={(e) => setFormData({ ...formData, planned_start_date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="planned_end_date">Data Fine Prevista</Label>
                  <Input
                    id="planned_end_date"
                    type="date"
                    value={formData.planned_end_date || ''}
                    onChange={(e) => setFormData({ ...formData, planned_end_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="progress_percentage">Progresso (%)</Label>
                <Input
                  id="progress_percentage"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.progress_percentage || ''}
                  onChange={(e) => setFormData({ ...formData, progress_percentage: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Note</Label>
                <Textarea
                  id="notes"
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Annulla
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? 'Salvataggio...' : 'Salva'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

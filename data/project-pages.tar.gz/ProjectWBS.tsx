import { useState, useEffect } from 'react';
import { useParams, useOutletContext } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Plus, 
  ChevronRight, 
  ChevronDown, 
  GripVertical,
  Pencil,
  Trash2,
  X,
  MoreHorizontal,
  Flag,
  Link as LinkIcon,
  Indent,
  Outdent
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { api } from '@/api/client';

const tasksApi = {
  list: (projectId: string) => api.get(`/tasks/by-project/${projectId}`),
  create: (data: any) => api.post('/tasks', data),
  update: (id: string, data: any) => api.put(`/tasks/${id}`, data),
  delete: (id: string) => api.delete(`/tasks/${id}`),
};

interface Task {
  id?: string;
  project_id: string;
  parent_task_id?: string | null;
  wbs_code?: string;
  name: string;
  description?: string;
  status: string;
  priority: string;
  assigned_to_user_id?: string | null;
  planned_start_date?: string;
  planned_end_date?: string;
  start_date?: string;
  end_date?: string;
  estimated_hours?: number;
  actual_hours?: number;
  progress_percentage?: number;
  is_milestone?: boolean;
  sort_order?: number;
  notes?: string;
  // Computed
  level?: number;
  children?: Task[];
  expanded?: boolean;
}

const emptyTask: Partial<Task> = {
  name: '',
  description: '',
  status: 'todo',
  priority: 'medium',
  planned_start_date: '',
  planned_end_date: '',
  estimated_hours: 0,
  progress_percentage: 0,
  is_milestone: false,
  notes: '',
};

const statusOptions = [
  { value: 'todo', label: 'Da fare', color: 'bg-gray-100 text-gray-800' },
  { value: 'in_progress', label: 'In corso', color: 'bg-blue-100 text-blue-800' },
  { value: 'review', label: 'In revisione', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'completed', label: 'Completato', color: 'bg-green-100 text-green-800' },
  { value: 'cancelled', label: 'Annullato', color: 'bg-red-100 text-red-800' },
];

const priorityOptions = [
  { value: 'low', label: 'Bassa', color: 'text-gray-500' },
  { value: 'medium', label: 'Media', color: 'text-blue-500' },
  { value: 'high', label: 'Alta', color: 'text-orange-500' },
  { value: 'urgent', label: 'Urgente', color: 'text-red-500' },
];

export function ProjectWBS() {
  const { projectId } = useParams<{ projectId: string }>();
  const context = useOutletContext<{ project: any }>();
  const project = context?.project;
  const queryClient = useQueryClient();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [parentTaskId, setParentTaskId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Task>>(emptyTask);
  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set());

  const { data: tasksResponse, isLoading } = useQuery({
    queryKey: ['tasks', projectId],
    queryFn: () => tasksApi.list(projectId!),
    enabled: !!projectId,
  });

  // Build hierarchical task tree
  const buildTaskTree = (tasks: Task[]): Task[] => {
    if (!tasks) return [];
    
    const taskMap = new Map<string, Task>();
    const rootTasks: Task[] = [];

    // First pass: create map and add children array
    tasks.forEach(task => {
      taskMap.set(task.id!, { ...task, children: [], level: 0 });
    });

    // Second pass: build hierarchy
    tasks.forEach(task => {
      const taskWithChildren = taskMap.get(task.id!);
      if (task.parent_task_id && taskMap.has(task.parent_task_id)) {
        const parent = taskMap.get(task.parent_task_id)!;
        taskWithChildren!.level = (parent.level || 0) + 1;
        parent.children!.push(taskWithChildren!);
      } else {
        rootTasks.push(taskWithChildren!);
      }
    });

    // Sort by sort_order and wbs_code
    const sortTasks = (tasks: Task[]) => {
      tasks.sort((a, b) => {
        if (a.sort_order !== b.sort_order) return (a.sort_order || 0) - (b.sort_order || 0);
        return (a.wbs_code || '').localeCompare(b.wbs_code || '');
      });
      tasks.forEach(t => {
        if (t.children?.length) sortTasks(t.children);
      });
    };

    sortTasks(rootTasks);
    return rootTasks;
  };

  const taskTree = buildTaskTree(tasksResponse?.data || []);
  const flatTasks = tasksResponse?.data || [];

  const createMutation = useMutation({
    mutationFn: (data: any) => tasksApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks', projectId] });
      queryClient.invalidateQueries({ queryKey: ['project', projectId] });
      setIsDialogOpen(false);
      setFormData(emptyTask);
      setParentTaskId(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => tasksApi.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks', projectId] });
      queryClient.invalidateQueries({ queryKey: ['project', projectId] });
      setIsDialogOpen(false);
      setEditingTask(null);
      setFormData(emptyTask);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => tasksApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks', projectId] });
      queryClient.invalidateQueries({ queryKey: ['project', projectId] });
    },
  });

  const handleOpenCreate = (parentId?: string) => {
    setEditingTask(null);
    setParentTaskId(parentId || null);
    setFormData({ ...emptyTask, project_id: projectId });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (task: Task) => {
    setEditingTask(task);
    setParentTaskId(task.parent_task_id || null);
    setFormData({
      ...task,
      planned_start_date: task.planned_start_date ? task.planned_start_date.split('T')[0] : '',
      planned_end_date: task.planned_end_date ? task.planned_end_date.split('T')[0] : '',
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSend = {
      ...formData,
      project_id: projectId,
      parent_task_id: parentTaskId || null,
      estimated_hours: formData.estimated_hours || 0,
      progress_percentage: formData.progress_percentage || 0,
      planned_start_date: formData.planned_start_date || null,
      planned_end_date: formData.planned_end_date || null,
    };
    
    if (editingTask?.id) {
      updateMutation.mutate({ id: editingTask.id, data: dataToSend });
    } else {
      createMutation.mutate(dataToSend);
    }
  };

  const handleDelete = (task: Task) => {
    const hasChildren = flatTasks.some(t => t.parent_task_id === task.id);
    const message = hasChildren 
      ? `Eliminare "${task.name}" e tutti i suoi sotto-task?`
      : `Eliminare "${task.name}"?`;
    
    if (confirm(message)) {
      deleteMutation.mutate(task.id!);
    }
  };

  const toggleExpand = (taskId: string) => {
    setExpandedTasks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  const getStatusInfo = (status: string) => statusOptions.find(s => s.value === status) || statusOptions[0];
  const getPriorityInfo = (priority: string) => priorityOptions.find(p => p.value === priority) || priorityOptions[1];

  const formatDate = (date?: string) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('it-IT', { day: '2-digit', month: 'short' });
  };

  // Render a single task row
  const renderTaskRow = (task: Task, level: number = 0) => {
    const hasChildren = (task.children?.length || 0) > 0;
    const isExpanded = expandedTasks.has(task.id!);
    const statusInfo = getStatusInfo(task.status);
    const priorityInfo = getPriorityInfo(task.priority);

    return (
      <div key={task.id}>
        <div 
          className={`flex items-center gap-2 py-2 px-3 border-b hover:bg-gray-50 group ${
            task.is_milestone ? 'bg-purple-50' : ''
          }`}
          style={{ paddingLeft: `${12 + level * 24}px` }}
        >
          {/* Expand/Collapse */}
          <div className="w-5 flex-shrink-0">
            {hasChildren ? (
              <button onClick={() => toggleExpand(task.id!)} className="p-0.5 hover:bg-gray-200 rounded">
                {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </button>
            ) : (
              <span className="w-4" />
            )}
          </div>

          {/* WBS Code */}
          <div className="w-16 flex-shrink-0 font-mono text-xs text-gray-500">
            {task.wbs_code || '-'}
          </div>

          {/* Milestone Icon */}
          {task.is_milestone && (
            <Flag className="h-4 w-4 text-purple-500 flex-shrink-0" />
          )}

          {/* Task Name */}
          <div className="flex-1 min-w-0">
            <span className={`truncate ${task.is_milestone ? 'font-semibold text-purple-700' : ''}`}>
              {task.name}
            </span>
          </div>

          {/* Status */}
          <div className="w-24 flex-shrink-0">
            <span className={`px-2 py-0.5 rounded-full text-xs ${statusInfo.color}`}>
              {statusInfo.label}
            </span>
          </div>

          {/* Priority */}
          <div className={`w-16 flex-shrink-0 text-xs ${priorityInfo.color}`}>
            {priorityInfo.label}
          </div>

          {/* Dates */}
          <div className="w-20 flex-shrink-0 text-xs text-gray-500">
            {formatDate(task.planned_start_date)}
          </div>
          <div className="w-20 flex-shrink-0 text-xs text-gray-500">
            {formatDate(task.planned_end_date)}
          </div>

          {/* Progress */}
          <div className="w-20 flex-shrink-0">
            <div className="flex items-center gap-1">
              <div className="w-12 bg-gray-200 rounded-full h-1.5">
                <div 
                  className="h-1.5 rounded-full bg-green-500"
                  style={{ width: `${task.progress_percentage || 0}%` }}
                />
              </div>
              <span className="text-xs text-gray-500">{task.progress_percentage || 0}%</span>
            </div>
          </div>

          {/* Hours */}
          <div className="w-16 flex-shrink-0 text-xs text-gray-500 text-right">
            {task.actual_hours || 0}/{task.estimated_hours || 0}h
          </div>

          {/* Actions */}
          <div className="w-24 flex-shrink-0 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleOpenCreate(task.id)}>
              <Plus className="h-3 w-3" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleOpenEdit(task)}>
              <Pencil className="h-3 w-3" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDelete(task)}>
              <Trash2 className="h-3 w-3 text-red-500" />
            </Button>
          </div>
        </div>

        {/* Render children if expanded */}
        {hasChildren && isExpanded && (
          <div>
            {task.children!.map(child => renderTaskRow(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  // Expand all by default on first load
  useEffect(() => {
    if (taskTree.length > 0 && expandedTasks.size === 0) {
      const allIds = new Set<string>();
      const collectIds = (tasks: Task[]) => {
        tasks.forEach(t => {
          if (t.children?.length) {
            allIds.add(t.id!);
            collectIds(t.children);
          }
        });
      };
      collectIds(taskTree);
      setExpandedTasks(allIds);
    }
  }, [taskTree]);

  if (isLoading) {
    return <div className="text-center py-8">Caricamento task...</div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Work Breakdown Structure</h2>
        <Button onClick={() => handleOpenCreate()}>
          <Plus className="h-4 w-4 mr-2" />
          Nuovo Task
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {/* Header */}
          <div className="flex items-center gap-2 py-2 px-3 bg-gray-100 border-b font-medium text-sm text-gray-600">
            <div className="w-5 flex-shrink-0" />
            <div className="w-16 flex-shrink-0">WBS</div>
            <div className="flex-1">Nome</div>
            <div className="w-24 flex-shrink-0">Stato</div>
            <div className="w-16 flex-shrink-0">Priorità</div>
            <div className="w-20 flex-shrink-0">Inizio</div>
            <div className="w-20 flex-shrink-0">Fine</div>
            <div className="w-20 flex-shrink-0">Progresso</div>
            <div className="w-16 flex-shrink-0 text-right">Ore</div>
            <div className="w-24 flex-shrink-0">Azioni</div>
          </div>

          {/* Task List */}
          {taskTree.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>Nessun task presente</p>
              <Button className="mt-4" onClick={() => handleOpenCreate()}>
                <Plus className="h-4 w-4 mr-2" />
                Crea il primo task
              </Button>
            </div>
          ) : (
            <div>
              {taskTree.map(task => renderTaskRow(task, 0))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      <div className="mt-4 flex gap-4 text-sm text-gray-600">
        <span>Totale task: {flatTasks.length}</span>
        <span>Completati: {flatTasks.filter(t => t.status === 'completed').length}</span>
        <span>In corso: {flatTasks.filter(t => t.status === 'in_progress').length}</span>
        <span>Da fare: {flatTasks.filter(t => t.status === 'todo').length}</span>
      </div>

      {/* Task Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingTask ? 'Modifica Task' : 'Nuovo Task'}
              {parentTaskId && !editingTask && (
                <span className="text-sm font-normal text-gray-500 ml-2">
                  (sotto-task)
                </span>
              )}
            </DialogTitle>
            <DialogDescription>
              {editingTask ? 'Modifica i dati del task' : 'Inserisci i dati del nuovo task'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome *</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrizione</Label>
                <Textarea
                  id="description"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Stato</Label>
                  <select
                    id="status"
                    value={formData.status || 'todo'}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    className="flex h-9 w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm"
                  >
                    {statusOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priorità</Label>
                  <select
                    id="priority"
                    value={formData.priority || 'medium'}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                    className="flex h-9 w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm"
                  >
                    {priorityOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2 flex items-end">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.is_milestone || false}
                      onChange={(e) => setFormData({ ...formData, is_milestone: e.target.checked })}
                      className="h-4 w-4 rounded border-gray-300"
                    />
                    <span className="text-sm">È una Milestone</span>
                    <Flag className="h-4 w-4 text-purple-500" />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="planned_start_date">Data Inizio</Label>
                  <Input
                    id="planned_start_date"
                    type="date"
                    value={formData.planned_start_date || ''}
                    onChange={(e) => setFormData({ ...formData, planned_start_date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="planned_end_date">Data Fine</Label>
                  <Input
                    id="planned_end_date"
                    type="date"
                    value={formData.planned_end_date || ''}
                    onChange={(e) => setFormData({ ...formData, planned_end_date: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="estimated_hours">Ore Stimate</Label>
                  <Input
                    id="estimated_hours"
                    type="number"
                    min="0"
                    step="0.5"
                    value={formData.estimated_hours || ''}
                    onChange={(e) => setFormData({ ...formData, estimated_hours: parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="progress_percentage">Progresso (%)</Label>
                  <Input
                    id="progress_percentage"
                    type="number"
                    min="0"
                    max="100"
                    value={formData.progress_percentage || ''}
                    onChange={(e) => setFormData({ ...formData, progress_percentage: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Note</Label>
                <Textarea
                  id="notes"
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Annulla
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? 'Salvataggio...' : 'Salva'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
